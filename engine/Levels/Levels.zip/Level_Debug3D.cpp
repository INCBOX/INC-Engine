// Level_Debug3D.cpp
#include "Level_Debug3D.h"
#include "engine_globals.h"
#include <glad/glad.h>
#include <SDL.h>

static GLuint vao = 0;
static GLuint vbo = 0;

void Level_Debug3D::Init() {
    float vertices[] = {
        // positions        // colors
        -0.5f, -0.5f, 0.0f,  1.0f, 0.0f, 0.0f,
         0.5f, -0.5f, 0.0f,  0.0f, 1.0f, 0.0f,
         0.0f,  0.5f, 0.0f,  0.0f, 0.0f, 1.0f,
    };

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

void Level_Debug3D::Update(float dt) {
    // No-op for now
}

void Level_Debug3D::Render() {
    gBasicShader.Bind();
    gBasicShader.SetUniformMat4("u_MVP", gProjMatrix * gViewMatrix);

    glBindVertexArray(vao);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindVertexArray(0);

    gBasicShader.Unbind();
}

void Level_Debug3D::Unload() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    vao = 0;
    vbo = 0;
}