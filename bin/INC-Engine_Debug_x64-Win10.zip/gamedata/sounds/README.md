# sounds Folder

This is the `resources/sounds` folder used in the INC-Engine project.