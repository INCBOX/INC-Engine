# textures Folder

This is the `resources/textures` folder used in the INC-Engine project.