# models Folder

This is the `resources/models` folder used in the INC-Engine project.